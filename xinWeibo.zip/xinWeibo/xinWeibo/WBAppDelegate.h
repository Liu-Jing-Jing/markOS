//
//  WBAppDelegate.h
//  xinWeibo
//
//  Created by Mark Lewis on 18-2-4.
//  Copyright (c) 2018年 MarkLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
