//
//  main.m
//  xinWeibo
//
//  Created by Mark Lewis on 18-2-4.
//  Copyright (c) 2018年 MarkLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WBAppDelegate class]));
    }
}
